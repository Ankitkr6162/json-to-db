package io.spring.consume.rest.api.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.spring.consume.rest.api.entities.MyDataEntity;
import io.spring.consume.rest.api.repository.MyDataRepository;
import jakarta.transaction.Transactional;



@Service
public class DataFetchingService {
    @Autowired
    private MyDataRepository dataRepository;
    @Autowired
    private RestTemplate restTemplate;

    

    @Transactional
    public void fetchDataAndSave() {
        String apiUrl = "https://jsonplaceholder.typicode.com/todos/1"; // Replace with your API URL

        // Fetch JSON from external API
        ResponseEntity<String> response = restTemplate.getForEntity(apiUrl, String.class);
        String jsonResponse = response.getBody();

        // Parse JSON using Jackson
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            MyDataEntity dataEntity = objectMapper.readValue(jsonResponse, MyDataEntity.class);

            // Save to the database
            dataRepository.save(dataEntity);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
