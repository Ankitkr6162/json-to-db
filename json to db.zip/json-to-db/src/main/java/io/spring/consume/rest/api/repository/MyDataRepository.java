package io.spring.consume.rest.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import io.spring.consume.rest.api.entities.MyDataEntity;
import jakarta.transaction.Transactional;

//@Transactional
public interface MyDataRepository extends JpaRepository<MyDataEntity, Long> {

}
