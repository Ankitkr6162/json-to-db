package io.spring.consume.rest.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonToDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
